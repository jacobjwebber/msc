import unittest

from sequence import Sequence

class SequenceTestCase(unittest.TestCase):

    def test_get_nucleotides(self):
        sequence_str = "GATTACCA"
        sequence = Sequence(sequence_str)
        self.assertEquals(sequence_str, sequence.nucleotides,
                          msg="Nucleotides returned were not those given")
    
    def test_get_weight(self):
        sequence = Sequence("G")
        self.assertAlmostEqual(Sequence.WEIGHTS['G'],
                               sequence.get_weight(), 
                               delta=0.01,
                               msg="Weight returned was unexpected")

    def test_calculate_weight(self):
        sequence = Sequence("G")
        self.assertAlmostEqual(Sequence.WEIGHTS['G'],
                               Sequence.calculate_weight(sequence), 
                               delta=0.01,
                               msg="Weight returned was unexpected")

    # Practical examples

    def test_get_nucleotides_lower_case(self):
        sequence_str = "gattacca"
        sequence = Sequence(sequence_str)
        self.assertEqual(sequence_str.upper(), 
                         sequence.nucleotides,
                         msg="Nucleotides returned were not those given")

    def test_calculate_weight_gattacca(self):
        sequence = Sequence("GATTACCA")
        self.assertAlmostEqual(1909.6,
                               Sequence.calculate_weight(sequence), 
                               delta=0.01,
                               msg="Weight returned was unexpected")

    def test_calculate_weight_acgt(self):
        sequence = Sequence("ACGT")
        self.assertAlmostEqual(1053.8,
                               Sequence.calculate_weight(sequence), 
                               delta=0.01,
                               msg="Weight returned was unexpected")

    def test_sequence_acgtx(self):
        with self.assertRaises(AssertionError):
            Sequence("ACGTX")
