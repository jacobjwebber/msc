package dna;

import static org.junit.Assert.*;
import org.junit.Test;
import dna.Sequence;

public class SequenceTest {

    @Test
    public void testGetNucleotides() {
        String sequenceStr = "GATTACCA";
        Sequence sequence = new Sequence(sequenceStr);
        assertEquals("Nucleotides returned were not those given", 
            sequenceStr, sequence.getNucleotides());
    }

    @Test
    public void testGetWeight() {
        Sequence sequence = new Sequence("G");
        assertEquals("Weight returned was unexpected", 
            Sequence.WEIGHTS.get('G').doubleValue(),
            sequence.getWeight(), 0.01);
    }

    @Test
    public void testCalculateWeight() {
        Sequence sequence = new Sequence("G");
        assertEquals("Weight returned was unexpected", 
            Sequence.WEIGHTS.get('G').doubleValue(),
            Sequence.calculateWeight(sequence), 0.01);
    }

    // Practical examples

    @Test
    public void testGetNucleotidesLowerCase() {
        String sequenceStr = "gattacca";
        Sequence sequence = new Sequence(sequenceStr);
        assertEquals("Nucleotides returned were not those given", 
            sequenceStr.toUpperCase(), sequence.getNucleotides());
    }

    @Test
    public void testCalculateWeightGattacca() {
        Sequence sequence = new Sequence("GATTACCA");
        assertEquals("Weight returned was unexpected", 
		     1909.6,
		     Sequence.calculateWeight(sequence),
		     0.01);
    }

    @Test
    public void testCalculateWeightAcgt() {
        Sequence sequence = new Sequence("ACGT");
        assertEquals("Weight returned was unexpected", 
		     1053.8,
		     Sequence.calculateWeight(sequence),
		     0.01);
    }

    @Test
    public void testSequenceAcgtx() {
        try {
            new Sequence("ACGTX");
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            // Expected.
        }
    }
}
